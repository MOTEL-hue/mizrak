import { type Page } from 'puppeteer-core';
export declare function getFromSessionStorage<T>(page: Page, key: string): Promise<T | null>;
