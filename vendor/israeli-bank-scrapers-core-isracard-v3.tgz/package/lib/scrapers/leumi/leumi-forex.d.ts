import { type Moment } from 'moment';
import { type Page } from 'puppeteer-core';
import { type Transaction, type TransactionsAccount } from '../../transactions';
import { type ScraperOptions } from '../interface';
/**
 * Leumi renders the currency as a Hebrew label rather than an ISO code, and the exact
 * punctuation varies (for example `דולר ארה"ב` vs `דולר ארה''ב`), so quotes and
 * whitespace are stripped before matching.
 */
export declare function mapForeignCurrency(label: string): string | undefined;
export declare function parseForeignAmount(cellText: string): number;
/**
 * A row carries the amount in either the debit or the credit column, never both.
 */
export declare function getForeignTransactionAmount(debitCellText: string, creditCellText: string): number;
export declare function mapForeignTransaction(cells: string[], currency: string, options?: ScraperOptions): Transaction;
export declare function fetchForeignCurrencyAccounts(page: Page, startDate: Moment, options: ScraperOptions): Promise<TransactionsAccount[]>;
