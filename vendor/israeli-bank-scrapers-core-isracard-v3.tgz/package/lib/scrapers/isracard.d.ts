import IsracardGroupScraper from './base-isracard/base-isracard';
import { type ScraperOptions } from './interface';
declare class IsracardScraper extends IsracardGroupScraper {
    constructor(options: ScraperOptions);
}
export default IsracardScraper;
