import { BaseScraperWithBrowser } from '../base-scraper-with-browser';
import { type ScraperOptions, type ScraperScrapingResult } from '../interface';
type ScraperSpecificCredentials = {
    id: string;
    password: string;
    card6Digits: string;
};
declare class IsracardGroupScraper extends BaseScraperWithBrowser<ScraperSpecificCredentials> {
    private loginBaseUrl;
    private webBaseUrl;
    private loginCompanyCode;
    private transactionsCompanyCode;
    constructor(options: ScraperOptions, loginBaseUrl: string, webBaseUrl: string, loginCompanyCode: string, transactionsCompanyCode: number);
    private get servicesUrl();
    private get cardListUrl();
    private get monthlyBillingUrl();
    private get transactionsUrl();
    login(credentials: ScraperSpecificCredentials): Promise<ScraperScrapingResult>;
    fetchData(): Promise<ScraperScrapingResult>;
}
export default IsracardGroupScraper;
