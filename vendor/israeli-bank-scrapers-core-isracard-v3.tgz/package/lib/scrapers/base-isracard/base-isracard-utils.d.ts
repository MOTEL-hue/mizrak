import { type Transaction, type TransactionInstallments } from '../../transactions';
import { type ScraperOptions } from '../interface';
export declare const DATE_FORMAT = "DD/MM/YYYY";
export declare const BILLING_MONTH_FORMAT = "MM/YYYY";
export interface ScrapedLoginValidation {
    Header: {
        Status: string;
    };
    ValidateIdDataBean?: {
        userName?: string;
        returnCode: string;
    };
}
export interface ScrapedCard {
    companyCode: string;
    cardStatus: string;
    cardSuffix: string;
    serviceType: string;
    isActive: boolean;
    isBlock: boolean;
    isPartner: boolean;
    limitData?: {
        creditLimitAmount: string;
        limitUsed: string;
    };
    cardChargeNext?: {
        billingDate: string;
    };
}
export interface ScrapedCardListResponse {
    data: {
        cardsList: ScrapedCard[];
    } | null;
    errorCode: string;
    errorDescription: string | null;
    isSuccess: boolean;
}
export interface ScrapedMonthlyBillingResponse {
    data: {
        cards: Record<string, {
            billingDate: string;
        }>;
    } | null;
    errorCode: string;
    errorDescription: string | null;
    isSuccess: boolean;
}
export interface ScrapedApprovedTransaction {
    purchaseDate: string;
    israelTransactionTime: string;
    businessName: string;
    originalAmount: number;
    currencyIso: string;
    ilsBillingAmount: number;
    extraDetails: string | null;
    seqConfirmationNumber: string;
    branchCodeDescription: string | null;
}
export interface ScrapedVoucher {
    purchaseDate: string;
    purchaseTime: string | null;
    businessName: string;
    originalAmount: number;
    originalCurrencyIso: string;
    billingAmount: number;
    moreInfo: string | null;
    seqVoucherNumber: string;
    currentInstallmentNum: number | null;
    numberOfInstallment: number | null;
    transactionDescription: string | null;
}
export interface ScrapedOutOfStatementGroup {
    immediateVouchersCurrencyDate: ScrapedVoucher[];
    totalVouchersCurrencyDate: {
        dateImmediateVouchers?: string;
    };
}
export interface ScrapedTransactionsResponse {
    data: {
        approvals: {
            approvedTransactions: ScrapedApprovedTransaction[];
        } | null;
        israelAbroadVouchers: {
            vouchers: {
                israelAbroadVouchersList: ScrapedVoucher[];
            };
            outOfStatementChargeDateVouchers: ScrapedOutOfStatementGroup[];
        } | null;
    } | null;
    errorCode: string;
    errorDescription: string | null;
    isSuccess: boolean;
}
export declare function getCardBalance(card: ScrapedCard): number | undefined;
export declare function getCardFrame(card: ScrapedCard): number | undefined;
export declare function getCardBalanceDate(card: ScrapedCard): string | undefined;
export declare function isApprovedTransactionSettled(approved: ScrapedApprovedTransaction, vouchers: ScrapedVoucher[]): boolean;
export declare function convertApprovedTransaction(txn: ScrapedApprovedTransaction, options?: ScraperOptions): Transaction;
export declare function getVoucherInstallments(voucher: ScrapedVoucher): TransactionInstallments | undefined;
export declare function convertVoucher(voucher: ScrapedVoucher, processedDateIso: string, options?: ScraperOptions): Transaction;
